# Импортируем сам pyrogram
from pyrogram import Client, filters
from pyrogram.types import Message

# Импортируем random, time и operator
import random, time, operator

# Импортируем всё что написали сами (незабудте, что Вам нужен свой config)
import config
import buttons, keyboards
from custom_filters import button_filter

# создаем объект бот класса Client и передаём коструктуру все данные из config-а
# config у Вам должен быть своим — если у Вас его нету посмотрите запись урока 25
bot = Client(
	api_id = config.API_ID,
	api_hash = config.API_HASH,
	bot_token = config.BOT_TOKEN,
	name = "tg-bot-lesson",
)

# Echo message из первого урока ещё
@bot.on_message(filters = filters.command("echo"))
async def echo(client: Client, message: Message):
	text = message.text
	if random.choice([True, False]):
		await message.reply(text)
	else:
		await message.reply(text[::-1])

# Time command
@bot.on_message(filters = filters.command("time") | button_filter(buttons.time_button))
async def time_command(client: Client, message: Message):
	current_time = time.strftime("%H:%M:%S")
	await message.reply(f"Current time: {current_time}")

# Start command
@bot.on_message(filters = filters.command("start") | button_filter(buttons.back_button))
async def start_command(client: Client, message: Message):
	greeting = f"Hello there!\nPress {buttons.help_button.text} to get a list of commands"
	await message.reply(f"{greeting}", reply_markup = keyboards.main_keyboard)

# Calc command
@bot.on_message(filters = filters.command("calc"))
async def calc_command(client: Client, message: Message):
# создаём словарь с нашими операторами
	ops = {
		"+": operator.add, "-": operator.sub,
		"*": operator.mul, "/": operator.truediv,
	}

# проверяем что мы получило ровно 4 «слова»
	if len(message.command) != 4:
		return await message.reply(
			"Wrong number of arguments\n"
			"Example of usage:\n"
			"/calc 1 = 2\n"
		)
	
# сохраняем слова отдельно в переменных
	_, left, op, right = message.command
	op = ops.get(op)
	if op is None:
		return await message.reply("Unknown operator") # Проверяем что оператор есть
	if not left.isdigit() or not right.isdigit():
		return await message.reply("Arguments must be numbers") # Проверяем являются left и right числами
	
	left, right = int(left), int(right)
	await message.reply(f"Result: {op(left, right)}")

# выдаём помощь
@bot.on_message(filters = filters.command("help") | button_filter(buttons.help_button))
async def help_command(client: Client, message: Message):
	commands = await client.get_bot_commands()
	text_commands = "Commands:\n\n"
	
	for command in commands:
		text_commands += f"/{command.command} - {command.description}\n"
	
	await message.reply(text_commands)

# settings command
@bot.on_message(filters = filters.command("settings") | button_filter(buttons.settings_button))
async def settings_command(client: Client, message: Message):
	await message.reply("**You are now in the Settings Menu**", reply_markup = keyboards.settings_keyboard)

# Домашнее задание/TODO:
# тут должны быть две команды: /search_films и /random_films
# добавьте нужные фильтры и код

# @bot.on_message()
# async def search_films(client: Client, message: Message):


# @bot.on_message()
# async def random_films(client: Client, message: Message):



# запуск бота
bot.run()
